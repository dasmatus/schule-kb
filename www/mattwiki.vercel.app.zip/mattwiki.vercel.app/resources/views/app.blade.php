<!DOCTYPE html>
<html lang="en" class="dark font-sans">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title inertia>{{ config('app.name') }}</title>
  @if(isset($page['props']['settings']['primary_l']))
  <style>
    .dark {
      --primary: oklch(
        {{ $page['props']['settings']['primary_l'] }}
        {{ $page['props']['settings']['primary_chroma'] }}
        {{ $page['props']['settings']['primary_hue'] }}
      );
    }
  </style>
  @endif
  @viteReactRefresh
  @vite(['resources/css/app.css', 'resources/js/app.tsx'])
  @inertiaHead
</head>
<body class="antialiased">@inertia</body>
</html>
