<!DOCTYPE html>
<html lang="en" class="dark font-sans">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title inertia><?php echo e(config('app.name')); ?></title>
  <?php if(isset($page['props']['settings']['primary_l'])): ?>
  <style>
    .dark {
      --primary: oklch(
        <?php echo e($page['props']['settings']['primary_l']); ?>

        <?php echo e($page['props']['settings']['primary_chroma']); ?>

        <?php echo e($page['props']['settings']['primary_hue']); ?>

      );
    }
  </style>
  <?php endif; ?>
  <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.tsx']); ?>
  <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>
<body class="antialiased"><?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?></body>
</html>
<?php /**PATH /var/home/matus/Dokumente/schule/mattwiki.vercel.app/resources/views/app.blade.php ENDPATH**/ ?>